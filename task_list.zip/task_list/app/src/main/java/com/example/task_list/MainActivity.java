package com.example.task_list;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView view;
    TextView no_task;
    ArrayList<String> id , tas,del;
    db_help dd;
    Adapter adapt;
    FloatingActionButton btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view = findViewById(R.id.rv);
        btn1 = findViewById(R.id.fab);
        no_task = findViewById(R.id.no_task);
        btn1.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, Add.class);
            startActivity(intent);
        });

        dd = new db_help(MainActivity.this);
        id = new ArrayList<>();
        tas = new ArrayList<>();
        del = new ArrayList<>();

        storeData();

        adapt = new Adapter(MainActivity.this, MainActivity.this, id,tas);
        view.setAdapter(adapt);
        view.setLayoutManager(new LinearLayoutManager(MainActivity.this));

    }

    void storeData(){
        Cursor cursor = dd.getdata();
        if(cursor.getCount() == 0){
            view.setVisibility(View.GONE);
            no_task.setVisibility(View.VISIBLE);
        }else{
            while (cursor.moveToNext()){
                id.add(cursor.getString(0));
                tas.add(cursor.getString(1));
            }
            view.setVisibility(View.VISIBLE);
            no_task.setVisibility(View.GONE);
        }
    }
    private void displaydata()
    {
        Cursor cursor = dd.getdata();
        if(cursor.getCount()==0)
        {
            Toast.makeText(MainActivity.this, "No tasks yet..", Toast.LENGTH_SHORT).show();
        }
        else
        {
            while(cursor.moveToNext())
            {
                id.add(cursor.getString(0));
                tas.add(cursor.getString(1));
            }
        }
    }
}