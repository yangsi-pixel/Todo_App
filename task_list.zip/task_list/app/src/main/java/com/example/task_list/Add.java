package com.example.task_list;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Add extends AppCompatActivity {
    TextView tv;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        tv = findViewById(R.id.tsk);
        btn = findViewById(R.id.btn2);
        btn.setOnClickListener(view -> {
            db_help myDB = new db_help(Add.this);
            myDB.addtsk(tv.getText().toString().trim());
        });
    }
}