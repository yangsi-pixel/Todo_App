package com.example.task_list;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Viewholder extends RecyclerView.ViewHolder {
    TextView tsk_id, tsk_nm;
    ImageView del;
    LinearLayout mainLayout;
    public Viewholder(@NonNull View itemView) {
        super(itemView);
        tsk_id = itemView.findViewById(R.id.id);
        tsk_nm = itemView.findViewById(R.id.tk);
        mainLayout = itemView.findViewById(R.id.card);
        del = itemView.findViewById(R.id.del);
    }
}
