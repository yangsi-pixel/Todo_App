package com.example.task_list;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Viewholder> {
    private ArrayList id, nm;
    private Context context;
    private Activity activity;
    Adapter(Activity activity, Context context, ArrayList id, ArrayList nm)
    {
        this.activity = activity;
        this.context = context;
        this.id = id;
        this.nm = nm;
    }
    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.look, parent, false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {
        holder.tsk_id.setText(String.valueOf(id.get(position)));
        holder.tsk_nm.setText(String.valueOf(nm.get(position)));

    }

    @Override
    public int getItemCount() {
        return id.size();
    }
}
